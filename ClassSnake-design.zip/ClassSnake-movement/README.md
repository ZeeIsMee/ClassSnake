# ClassSnake
This is the BCCC Visual Basic Studio class final project for Fall 2021.

This project is being developed in three branches, described below

#Collision Branch
Work on this branch focuses on the snake's interaction with the edges of the game board and crossing paths with itself.

#Movement Branch
Work on this branch focuses on the movement of the snake.

#Scoring Branch
This branch focuses on the dots that are randomly spawned on the board to be eaten by the snake.

#Testing
When you are ready to see if your code interacts correctly with the rest of the code, merge with the testing branch.

For any changes you will create a pull request to the branch you are working on. Once changes have been tested and iterated, they may be merged to the main branch.
